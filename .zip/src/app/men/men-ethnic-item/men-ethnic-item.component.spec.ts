import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenEthnicItemComponent } from './men-ethnic-item.component';

describe('MenEthnicItemComponent', () => {
  let component: MenEthnicItemComponent;
  let fixture: ComponentFixture<MenEthnicItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MenEthnicItemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenEthnicItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
