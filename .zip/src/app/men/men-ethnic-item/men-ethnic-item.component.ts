import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-men-ethnic-item',
  templateUrl: './men-ethnic-item.component.html',
  styleUrls: ['./men-ethnic-item.component.css']
})
export class MenEthnicItemComponent implements OnInit {
  details:any
  constructor(public ar:ActivatedRoute) { }

  ngOnInit(): void {
    this.ar.queryParams.subscribe((res:any)=>
    {
      this.details=res
    })
  }

}
