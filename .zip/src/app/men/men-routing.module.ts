import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MenEthnicItemComponent } from './men-ethnic-item/men-ethnic-item.component';
import { MenEthnicComponent } from './men-ethnic/men-ethnic.component';
import { MenWesternItemComponent } from './men-western-item/men-western-item.component';
import { MenWesternComponent } from './men-western/men-western.component';
import { MenComponent } from './men/men.component';

const routes: Routes = [
  {
    path:'',
    component:MenComponent,
    children:[
      {
        path:'men-ethnic',
        component:MenEthnicComponent
      },
      {
        path:'men-western',
        component:MenWesternComponent
      },
      {
        path:'men-ethnic-item',
        component:MenEthnicItemComponent
      },
      {
        path:'men-western-item',
        component:MenWesternItemComponent
      }
    ]
  }  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MenRoutingModule { }
