import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-men-western',
  templateUrl: './men-western.component.html',
  styleUrls: ['./men-western.component.css']
})
export class MenWesternComponent implements OnInit {

  constructor() { }
  models:any=[
    {
      item:"Shirts",
      image:"https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/2221318/2017/12/6/11512544982740-Moda-Rapido-Men-Maroon-Colourblocked-Round-Neck-T-shirt-4391512544982619-1.jpg",
      price:999,
      discount:0.05
    },
    {
      item:"Blazers",
      image:"https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/productimage/2019/5/24/a23bbfe7-59ff-4630-8695-3b3c9f9f9fb01558658372372-1.jpg",
      price:4999,
      discount:0.05
    },
    {
      item:"Jackets",
      image:"https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/10730652/2019/11/7/ebe0f2f8-c9e4-49e7-bb04-9dd37d397a6d1573117874825-LOCOMOTIVE-Men-Blue-Solid-Denim-Jacket-7091573117872407-1.jpg",
      price:1999,
      discount:0.05
    }
  ]
  ngOnInit(): void {
  }

}
