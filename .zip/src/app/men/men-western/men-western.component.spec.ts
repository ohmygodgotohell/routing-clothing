import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenWesternComponent } from './men-western.component';

describe('MenWesternComponent', () => {
  let component: MenWesternComponent;
  let fixture: ComponentFixture<MenWesternComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MenWesternComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenWesternComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
