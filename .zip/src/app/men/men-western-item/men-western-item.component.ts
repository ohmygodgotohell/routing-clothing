import { Component, OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-men-western-item',
  templateUrl: './men-western-item.component.html',
  styleUrls: ['./men-western-item.component.css']
})
export class MenWesternItemComponent implements OnInit {
  details:any;
  constructor(public ar:ActivatedRoute) { }

  ngOnInit(): void {
    this.ar.queryParams.subscribe((res:any)=>
    {
      this.details=res
    })
  }

}
