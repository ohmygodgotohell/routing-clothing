import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenWesternItemComponent } from './men-western-item.component';

describe('MenWesternItemComponent', () => {
  let component: MenWesternItemComponent;
  let fixture: ComponentFixture<MenWesternItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MenWesternItemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenWesternItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
