import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MenRoutingModule } from './men-routing.module';
import { MenComponent } from './men/men.component';
import { MenEthnicComponent } from './men-ethnic/men-ethnic.component';
import { MenWesternComponent } from './men-western/men-western.component';
import { MenEthnicItemComponent } from './men-ethnic-item/men-ethnic-item.component';
import { MenWesternItemComponent } from './men-western-item/men-western-item.component';


@NgModule({
  declarations: [
    MenComponent,
    MenEthnicComponent,
    MenWesternComponent,
    MenEthnicItemComponent,
    MenWesternItemComponent
  ],
  imports: [
    CommonModule,
    MenRoutingModule
  ],
  exports:[
    
  ]
})
export class MenModule { }
