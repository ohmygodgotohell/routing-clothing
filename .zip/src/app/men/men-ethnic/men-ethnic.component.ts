import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-men-ethnic',
  templateUrl: './men-ethnic.component.html',
  styleUrls: ['./men-ethnic.component.css']
})
export class MenEthnicComponent implements OnInit {

  constructor() { }
   models:any=[
    {
      item:"Sherwani",
      image:"https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/productimage/2020/11/23/5f5ccf45-6f61-4f41-9736-f6dbfeddd5771606117589368-1.jpg",
      price:5000,
      discount:0.05
    },
    {
      item:"Kurta Sets",
      image:"https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/11199314/2021/3/10/6c7ed065-29ba-452d-a742-0b51f04b51121615360729206-Anouk-Men-Kurta-Sets-2371615360726721-1.jpg",
      price:6000,
      discount:0.06
    },
    {
      item:"Suits",
      image:"https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/15867224/2021/11/10/44e81630-ad02-4500-a485-c352f9b11dbb1636521136820-Manu-Men-Suits-4991636521135873-1.jpg",
      price:8000,
      discount:0.09
    }
  ]
  ngOnInit(): void {
  }

}
