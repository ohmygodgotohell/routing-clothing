import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-women-western',
  templateUrl: './women-western.component.html',
  styleUrls: ['./women-western.component.css']
})
export class WomenWesternComponent implements OnInit {

  constructor() { }
  models=[
    {
      item:"Tops",
      image:"https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/productimage/2021/2/3/e3f8e0f6-df93-4cba-bd4c-3199c17134a51612356462929-3.jpg",
      Price: 3000,
      Discount:0.06


    },
    {
      item:"Jumpsuits",
      image:"https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/11478656/2020/2/14/32d89698-3426-4001-b215-b3897d07b0b51581662298221-The-Vanca-Women-Grey--Pink-Printed-Basic-Jumpsuit-8015816622-1.jpg",
      Price: 5000,
      Discount:0.1
    },
    {
      item:"Skirts",
      image:"https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/productimage/2019/8/7/15422b8f-ed93-4246-b9ef-92fa8c6e87011565154946076-1.jpg",
      Price: 2000,
      Discount:0.09
    }
  ]
  ngOnInit(): void {
  }

}
