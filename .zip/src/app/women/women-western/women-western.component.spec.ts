import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WomenWesternComponent } from './women-western.component';

describe('WomenWesternComponent', () => {
  let component: WomenWesternComponent;
  let fixture: ComponentFixture<WomenWesternComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WomenWesternComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WomenWesternComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
