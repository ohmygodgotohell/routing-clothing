import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WomenRoutingModule } from './women-routing.module';
import { WomenComponent } from './women/women.component';
import { WomenEthnicComponent } from './women-ethnic/women-ethnic.component';
import { WomenWesternComponent } from './women-western/women-western.component';
import { WomenEthnicItemComponent } from './women-ethnic-item/women-ethnic-item.component';
import { WomenWesternItemComponent } from './women-western-item/women-western-item.component';


@NgModule({
  declarations: [
    WomenComponent,
    WomenEthnicComponent,
    WomenWesternComponent,
    WomenEthnicItemComponent,
    WomenWesternItemComponent
  ],
  imports: [
    CommonModule,
    WomenRoutingModule
  ],
  exports:[
    
  ]
})
export class WomenModule { }
