import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WomenEthnicItemComponent } from './women-ethnic-item.component';

describe('WomenEthnicItemComponent', () => {
  let component: WomenEthnicItemComponent;
  let fixture: ComponentFixture<WomenEthnicItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WomenEthnicItemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WomenEthnicItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
