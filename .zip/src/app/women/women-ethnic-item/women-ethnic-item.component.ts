import { Component, OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-women-ethnic-item',
  templateUrl: './women-ethnic-item.component.html',
  styleUrls: ['./women-ethnic-item.component.css']
})
export class WomenEthnicItemComponent implements OnInit {
  details:any;
  
  constructor(public ar:ActivatedRoute) { }

  ngOnInit(): void {
    this.ar.queryParams.subscribe((res:any)=>
    {
      this.details=res;
    })
  }

}
