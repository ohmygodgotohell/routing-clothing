import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WomenEthnicComponent } from './women-ethnic/women-ethnic.component';
import { WomenWesternComponent } from './women-western/women-western.component';
import { WomenComponent } from './women/women.component';

const routes: Routes = [
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WomenRoutingModule { }
