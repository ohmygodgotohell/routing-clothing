import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WomenWesternItemComponent } from './women-western-item.component';

describe('WomenWesternItemComponent', () => {
  let component: WomenWesternItemComponent;
  let fixture: ComponentFixture<WomenWesternItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WomenWesternItemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WomenWesternItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
