import { Component, OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-women-western-item',
  templateUrl: './women-western-item.component.html',
  styleUrls: ['./women-western-item.component.css']
})
export class WomenWesternItemComponent implements OnInit {
  details:any
  constructor(public ar:ActivatedRoute) { }
  

  ngOnInit(): void {
    this.ar.queryParams.subscribe((res:any)=>
    {
      this.details=res;
    })
  }

}
