import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-women-ethnic',
  templateUrl: './women-ethnic.component.html',
  styleUrls: ['./women-ethnic.component.css']
})
export class WomenEthnicComponent implements OnInit {

  constructor() { }
  models:any=[
    {
      item:"Kurti",
      image:"https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/8969717/2019/3/28/e448c9a1-3a0f-40e7-b267-1bf44a44ba501553778956208-Indo-Era-Beige-Solid-Straight-Kurta-Sets-9801553778954623-1.jpg",
      price:5000,
      discount:0.05
    },
    {
      item:"Lehanga",
      image:"https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/14845310/2021/7/15/9156dec7-3f11-4a60-94d0-1795d6ebe2fd1626371270558SHOPGARBWomenRed1.jpg",
      price:8000,
      discount:0.09
    },
    {
      item:"Saree",
      image:"https://assets.myntassets.com/f_webp,dpr_1.0,q_60,w_210,c_limit,fl_progressive/assets/images/16697006/2022/1/5/4672c4bf-8fe1-4523-91f4-ac08301573251641392147135KALINIWomenMaroonWovenDesign1.jpg",
      price:6000,
      discount:0.08
    }
  ]
  ngOnInit(): void {
  }

}
