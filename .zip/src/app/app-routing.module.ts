import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MenComponent } from './men/men/men.component';
import { WomenEthnicItemComponent } from './women/women-ethnic-item/women-ethnic-item.component';
import { WomenEthnicComponent } from './women/women-ethnic/women-ethnic.component';
import { WomenWesternItemComponent } from './women/women-western-item/women-western-item.component';
import { WomenWesternComponent } from './women/women-western/women-western.component';
import { WomenComponent } from './women/women/women.component';

const routes: Routes = [
  {
    path:'',
    component:HomeComponent,
    children:[
      {

        path:'men',
        loadChildren: () => import('./men/men.module').then(m => m.MenModule)
        
      },
      {
        path:'women',
        component:WomenComponent,
        children:[
          {
            path:"women-ethnic",
            component:WomenEthnicComponent
          },
          {
            path:'women-western',
            component:WomenWesternComponent
          },
          {
            path:'women-western-item',
            component:WomenWesternItemComponent
          },
          {
            path:'women-ethnic-item',
            component:WomenEthnicItemComponent
          }
        ]
      }
    ]
  },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
